<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barcode Scanner</title>
</head>
<body>
    <h1>Click the button to open the camera for barcode scanning</h1>
    <button onclick="openCamera()">Open Camera</button>
    <div id="scanner" style="display: none;"></div>

    
        
</body>
</html>
