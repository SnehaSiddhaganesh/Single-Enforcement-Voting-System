-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2024 at 03:13 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `voter`
--

-- --------------------------------------------------------

--
-- Table structure for table `voter_reg`
--

CREATE TABLE `voter_reg` (
  `v_epic_no` int(255) NOT NULL,
  `v_state` varchar(255) NOT NULL,
  `v_district` varchar(255) NOT NULL,
  `v_no_ac` bigint(15) NOT NULL,
  `v_name_ac` varchar(255) NOT NULL,
  `v_no_pc` bigint(15) NOT NULL,
  `v_name_pc` varchar(255) NOT NULL,
  `v_first_name` varchar(255) NOT NULL,
  `v_middle_name` varchar(256) NOT NULL,
  `v_surname` varchar(255) NOT NULL,
  `v_photo_file` longblob NOT NULL,
  `v_relative` varchar(255) NOT NULL,
  `v_relative_name` varchar(255) NOT NULL,
  `v_relative_surname` varchar(255) NOT NULL,
  `v_mobile_no_type` varchar(255) NOT NULL,
  `v_mobile_no` bigint(15) NOT NULL,
  `v_mobile_otp` bigint(15) NOT NULL,
  `v_email_type` varchar(255) NOT NULL,
  `v_email_id` varchar(255) NOT NULL,
  `v_aadhaar_detail` varchar(255) NOT NULL,
  `v_aadhaar_no` bigint(15) NOT NULL,
  `v_gender` varchar(255) NOT NULL,
  `v_dob` date NOT NULL,
  `v_dob_proof_type` varchar(255) NOT NULL,
  `v_dob_proof_other` varchar(255) NOT NULL,
  `v_dob_proof_file` longblob NOT NULL,
  `v_address_house_no` varchar(255) NOT NULL,
  `v_address_street` varchar(255) NOT NULL,
  `v_address_village` varchar(255) NOT NULL,
  `v_address_post_office` varchar(255) NOT NULL,
  `v_address_pin_code` bigint(15) NOT NULL,
  `v_address_tehsil` varchar(255) NOT NULL,
  `v_address_district` varchar(255) NOT NULL,
  `v_address_state` varchar(255) NOT NULL,
  `v_address_proof_type` varchar(255) NOT NULL,
  `v_address_proof_other` varchar(255) NOT NULL,
  `v_address_proof_file` longblob NOT NULL,
  `v_category_of_disability` varchar(255) NOT NULL,
  `v_category_of_disability_other` varchar(255) NOT NULL,
  `v_percentage_of_disability` varchar(255) NOT NULL,
  `v_disability_certificate_attached` varchar(255) NOT NULL,
  `v_disability_certificate_file` longblob NOT NULL,
  `v_family_member_name` varchar(255) NOT NULL,
  `v_family_member_relationship` varchar(255) NOT NULL,
  `v_family_member_epic` varchar(255) NOT NULL,
  `v_declaration_village` varchar(255) NOT NULL,
  `v_declaration_state` varchar(255) NOT NULL,
  `v_declaration_district` varchar(255) NOT NULL,
  `v_declaration_resident_date` date NOT NULL,
  `v_declaration_document` varchar(255) NOT NULL,
  `v_declaration_place` varchar(255) NOT NULL,
  `v_declaration_date` date NOT NULL,
  `v_captcha` varchar(255) NOT NULL,
  `v_qrcode` blob NOT NULL,
  `v_verify` varchar(255) DEFAULT NULL,
  `voted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `v_flag` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `voter_reg`
--

INSERT INTO `voter_reg` (`v_epic_no`, `v_state`, `v_district`, `v_no_ac`, `v_name_ac`, `v_no_pc`, `v_name_pc`, `v_first_name`, `v_middle_name`, `v_surname`, `v_photo_file`, `v_relative`, `v_relative_name`, `v_relative_surname`, `v_mobile_no_type`, `v_mobile_no`, `v_mobile_otp`, `v_email_type`, `v_email_id`, `v_aadhaar_detail`, `v_aadhaar_no`, `v_gender`, `v_dob`, `v_dob_proof_type`, `v_dob_proof_other`, `v_dob_proof_file`, `v_address_house_no`, `v_address_street`, `v_address_village`, `v_address_post_office`, `v_address_pin_code`, `v_address_tehsil`, `v_address_district`, `v_address_state`, `v_address_proof_type`, `v_address_proof_other`, `v_address_proof_file`, `v_category_of_disability`, `v_category_of_disability_other`, `v_percentage_of_disability`, `v_disability_certificate_attached`, `v_disability_certificate_file`, `v_family_member_name`, `v_family_member_relationship`, `v_family_member_epic`, `v_declaration_village`, `v_declaration_state`, `v_declaration_district`, `v_declaration_resident_date`, `v_declaration_document`, `v_declaration_place`, `v_declaration_date`, `v_captcha`, `v_qrcode`, `v_verify`, `voted_at`, `v_flag`) VALUES
(1, 'Maharashtra', 'Solapur', 0, '', 0, '', 'Shruti', 'Sagar', 'Jalkote', 0x622e6a7067, 'Father', 'Sagar', 'Jalkote', 'self', 7350522745, 1234, '', 's@gmail.com', '', 895032752197, 'Female', '2005-11-06', 'Birth Certificate', '6/09/2005', 0x62617070612e6a7067, '101', 'Gavali vasti,', 'Solapur', 'Akashwani kendra', 413003, 'Solapur', 'Solapur', 'Maharashtra', '', '', '', 'Locomotive', '', '', 'on', 0x622e6a7067, 'Sachin', 'Brother', 'ABC5678435', 'Solapur', 'Solapur', 'Maharashtra', '0000-00-00', '', 'solapur', '2024-03-20', '', '', 'verified', '2024-03-20 03:56:59', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `voter_reg`
--
ALTER TABLE `voter_reg`
  ADD PRIMARY KEY (`v_aadhaar_no`) USING BTREE,
  ADD UNIQUE KEY `v_epic_no` (`v_epic_no`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
